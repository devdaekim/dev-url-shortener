<?php return array (
  'auth.login' => 'App\\Http\\Livewire\\Auth\\Login',
  'auth.register' => 'App\\Http\\Livewire\\Auth\\Register',
  'forgot-password' => 'App\\Http\\Livewire\\ForgotPassword',
  'links-list' => 'App\\Http\\Livewire\\LinksList',
  'reset-password' => 'App\\Http\\Livewire\\ResetPassword',
  'shortened-link' => 'App\\Http\\Livewire\\ShortenedLink',
);